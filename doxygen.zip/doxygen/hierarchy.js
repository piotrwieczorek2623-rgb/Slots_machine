var hierarchy =
[
    [ "Drum", "classDrum.html", null ],
    [ "Game", "classGame.html", null ],
    [ "QMainWindow", null, [
      [ "MainWindow", "classMainWindow.html", null ]
    ] ],
    [ "Symbol", "classSymbol.html", [
      [ "Fruit", "classFruit.html", [
        [ "Cherry", "classCherry.html", null ],
        [ "Lemon", "classLemon.html", null ],
        [ "Plum", "classPlum.html", null ]
      ] ],
      [ "SpecialSymbol", "classSpecialSymbol.html", [
        [ "Bomb", "classBomb.html", null ],
        [ "Seven", "classSeven.html", null ]
      ] ]
    ] ]
];