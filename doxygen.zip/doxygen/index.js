var index =
[
    [ "Opis projektu", "index.html#autotoc_md0", null ],
    [ "Architektura", "index.html#autotoc_md1", null ],
    [ "Najważniejsze klasy logiki", "index.html#autotoc_md2", null ],
    [ "Mechanika losowania", "index.html#autotoc_md3", null ],
    [ "Reguły wygranej", "index.html#autotoc_md4", null ],
    [ "Generowanie dokumentacji", "index.html#autotoc_md5", null ]
];