var classGame =
[
    [ "Game", "classGame.html#ad59df6562a58a614fda24622d3715b65", null ],
    [ "getBet", "classGame.html#a702fa2c804e1fd47282570e905defb9f", null ],
    [ "getCredits", "classGame.html#a0d97a65664bb417daf66bb7fdca49345", null ],
    [ "getCurrentSpin", "classGame.html#a7711f7e5b8c9fae271c917cd7bf14189", null ],
    [ "playRound", "classGame.html#ae1b52ba5d4db3d4c924dcec9fa97e6c2", null ],
    [ "setBet", "classGame.html#afbb7a28aa4ed95519cb140d72fc1da75", null ],
    [ "start", "classGame.html#a3d9b98f7c4a96ecf578f75b96c9f0e90", null ],
    [ "bet", "classGame.html#a17c56b33a5e3ba39e413cf70a70a3fa2", null ],
    [ "credits", "classGame.html#a3155f195ebcc56ae40cf170c574aa58e", null ],
    [ "drum", "classGame.html#abc57819e2ce8a951a848dcf09f9c28e6", null ]
];