var searchData=
[
  ['name_0',['name',['../classSymbol.html#aae414c7ddc8c0cfcd3678d5142490f11',1,'Symbol']]]
];
