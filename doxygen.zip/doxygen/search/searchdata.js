var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstvw~ż",
  1: "bcdfglmps",
  2: "abcdfgilmprs",
  3: "abcdfghilmoprstw~",
  4: "bcdegimnprstvw",
  5: "s",
  6: "gim",
  7: "dps"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "pages"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Pliki",
  3: "Funkcje",
  4: "Zmienne",
  5: "Wyliczenia",
  6: "Wartości wyliczeń",
  7: "Strony"
};

