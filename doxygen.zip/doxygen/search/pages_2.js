var searchData=
[
  ['slotsmachine_0',['Dokumentacja projektu SlotsMachine',['../index.html',1,'']]]
];
