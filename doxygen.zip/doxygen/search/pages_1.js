var searchData=
[
  ['projektu_20slotsmachine_0',['Dokumentacja projektu SlotsMachine',['../index.html',1,'']]]
];
