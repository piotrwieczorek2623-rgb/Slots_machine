var searchData=
[
  ['titleinfolabel_0',['titleInfoLabel',['../classMainWindow.html#abd6d063d0918a02c9e49f8b1d6e082bb',1,'MainWindow']]],
  ['titlemenulabel_1',['titleMenuLabel',['../classMainWindow.html#ae952250542786c908a208b830d6f1eb0',1,'MainWindow']]]
];
