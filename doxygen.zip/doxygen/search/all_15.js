var searchData=
[
  ['życia_20symboli_0',['Cykl życia symboli',['../classDrum.html#drum_lifecycle',1,'']]]
];
