var searchData=
[
  ['reel1_0',['reel1',['../classMainWindow.html#afd923571d8a035a99d20851fd3d4b417',1,'MainWindow']]],
  ['reel1effect_1',['reel1Effect',['../classMainWindow.html#aecdec0753c8286899753303ebe0c1fe4',1,'MainWindow']]],
  ['reel2_2',['reel2',['../classMainWindow.html#ae53011872107ede9cc4557fa8e0cc82d',1,'MainWindow']]],
  ['reel2effect_3',['reel2Effect',['../classMainWindow.html#ad61262ab8c0f9784e14c64cc52a5a72b',1,'MainWindow']]],
  ['reel3_4',['reel3',['../classMainWindow.html#ad9924c390063a253d451acc7a9a5318d',1,'MainWindow']]],
  ['reel3effect_5',['reel3Effect',['../classMainWindow.html#ab36b4b7075d5fce91ee1169a2fe9fc46',1,'MainWindow']]],
  ['returntomenubutton_6',['returnToMenuButton',['../classMainWindow.html#ae700dfb710c3d5ef4c36340289326250',1,'MainWindow']]]
];
