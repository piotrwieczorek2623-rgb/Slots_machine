var searchData=
[
  ['klasy_20logiki_0',['Najważniejsze klasy logiki',['../index.html#autotoc_md2',1,'']]]
];
