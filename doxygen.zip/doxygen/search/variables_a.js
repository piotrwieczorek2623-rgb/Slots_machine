var searchData=
[
  ['spinbutton_0',['spinButton',['../classMainWindow.html#a3612e8dce92627c0f9cc82c03161f5aa',1,'MainWindow']]],
  ['stackedwidget_1',['stackedWidget',['../classMainWindow.html#aa86720a51d3246a6dc316d51488dcb15',1,'MainWindow']]],
  ['symbols_2',['symbols',['../classDrum.html#a4d18bbec53e81e7483738441e3c7f9c0',1,'Drum']]]
];
