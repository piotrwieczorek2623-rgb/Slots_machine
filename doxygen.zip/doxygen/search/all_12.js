var searchData=
[
  ['videowidget_0',['videoWidget',['../classMainWindow.html#a864558ff87b64a491d601b9b2e31df0b',1,'MainWindow']]]
];
