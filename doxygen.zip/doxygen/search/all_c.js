var searchData=
[
  ['najważniejsze_20klasy_20logiki_0',['Najważniejsze klasy logiki',['../index.html#autotoc_md2',1,'']]],
  ['name_1',['name',['../classSymbol.html#aae414c7ddc8c0cfcd3678d5142490f11',1,'Symbol']]]
];
