var searchData=
[
  ['obiektu_0',['Stan obiektu',['../classGame.html#game_state',1,'']]],
  ['oninfoclicked_1',['onInfoClicked',['../classMainWindow.html#a4a176e344da4ce60b74c0667e10b754e',1,'MainWindow']]],
  ['onplayclicked_2',['onPlayClicked',['../classMainWindow.html#a4528a5380814698373ff9e411bfbc57a',1,'MainWindow']]],
  ['onreturninfoclicked_3',['onReturnInfoClicked',['../classMainWindow.html#a1e83fa5c7af44bcf523dd8584cd5eb73',1,'MainWindow']]],
  ['opis_20projektu_4',['Opis projektu',['../index.html#autotoc_md0',1,'']]]
];
