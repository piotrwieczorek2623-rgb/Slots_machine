var classDrum =
[
    [ "Drum", "classDrum.html#a89a8ff180c09bc6ea452c28f32005da7", null ],
    [ "~Drum", "classDrum.html#aa2977e79f07e0c73892454eb6d593881", null ],
    [ "calculateWin", "classDrum.html#ae608dfc1e9aefc8bc60570363b094ba5", null ],
    [ "forceWin", "classDrum.html#ac8c28bdc449e2cfe7b90bf0c89253de3", null ],
    [ "getCurrentSpin", "classDrum.html#a1cf024160a714ea5d2699e4566fe470a", null ],
    [ "isWin", "classDrum.html#a6febbcd4398cdcc6b47be12543639c53", null ],
    [ "randSymbol", "classDrum.html#a20ccb8faf7ea83e0fa2eedfbd838d39d", null ],
    [ "spin", "classDrum.html#a883bf6b2a4a745ed8fdca6d5735a4b2d", null ],
    [ "win", "classDrum.html#ae4d30d5928bf6d47ac16e427583141c5", null ],
    [ "curr_spin", "classDrum.html#a2b185171eb0984cd0fba025c4a1e9dbd", null ],
    [ "drums_quantity", "classDrum.html#a46a7102e9c1fded8df1abd4abb225cc3", null ],
    [ "symbols", "classDrum.html#a4d18bbec53e81e7483738441e3c7f9c0", null ]
];