var classFruit =
[
    [ "Fruit", "classFruit.html#afe6207ceb32fdbdec2a4c971442be8d1", null ],
    [ "~Fruit", "classFruit.html#ae5cb0e5b74184cfbe94e04d82fd08bf0", null ]
];