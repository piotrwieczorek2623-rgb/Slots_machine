var annotated_dup =
[
    [ "Bomb", "classBomb.html", "classBomb" ],
    [ "Cherry", "classCherry.html", "classCherry" ],
    [ "Drum", "classDrum.html", "classDrum" ],
    [ "Fruit", "classFruit.html", "classFruit" ],
    [ "Game", "classGame.html", "classGame" ],
    [ "Lemon", "classLemon.html", "classLemon" ],
    [ "MainWindow", "classMainWindow.html", "classMainWindow" ],
    [ "Plum", "classPlum.html", "classPlum" ],
    [ "Seven", "classSeven.html", "classSeven" ],
    [ "SpecialSymbol", "classSpecialSymbol.html", "classSpecialSymbol" ],
    [ "Symbol", "classSymbol.html", "classSymbol" ]
];