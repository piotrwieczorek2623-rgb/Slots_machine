var classPlum =
[
    [ "Plum", "classPlum.html#acafa0b8eeea6c1b7ba6594e3628e07d9", null ],
    [ "~Plum", "classPlum.html#a506019b7c5f30476aa1be058331e73eb", null ],
    [ "getPath", "classPlum.html#a83eeaa73bf1e80a5bf125de360eb1f0a", null ]
];